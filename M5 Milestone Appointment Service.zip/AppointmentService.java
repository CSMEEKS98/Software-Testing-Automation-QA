package Main;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    final Map<String, Appointment> appointments = new HashMap<>();

    // Add an appointment
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Previously Created: Appointment ID");
        }
        appointments.put(appointment.getAppointmentID(), appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentID) {
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Unable to Locate: Appointment ID");
        }
        appointments.remove(appointmentID);
    }
}
