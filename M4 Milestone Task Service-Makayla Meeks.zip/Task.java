/* Author: Makayla Meeks 
 * Date: January 30, 2025 */


package Main;

public class Task {
    private final String taskID;
    private String name;
    private String description;

    // Constructor
    public Task(String taskID, String name, String description) {
        if (taskID == null || taskID.length() > 10) {
            throw new IllegalArgumentException("Unacceptable Task ID");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Unacceptable Name");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Unacceptable Description");
        }
        this.taskID = taskID;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskID() {
        return taskID;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Unacceptable Name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Unacceptable Description");
        }
        this.description = description;
    }
}
